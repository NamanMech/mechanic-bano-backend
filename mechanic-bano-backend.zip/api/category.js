import { connectDB } from '../utils/connectDB';

export default async function handler(req, res) {
  const client = await connectDB();
  const db = client.db('mechanic_bano');
  const collection = db.collection('categories');

  if (req.method === 'GET') {
    const categories = await collection.find().toArray();
    return res.json(categories);
  }

  if (req.method === 'POST') {
    const { name, description } = req.body;
    await collection.insertOne({ name, description });
    return res.json({ message: 'Category added successfully' });
  }

  if (req.method === 'DELETE') {
    const { id } = req.query;
    await collection.deleteOne({ _id: new ObjectId(id) });
    return res.json({ message: 'Category deleted successfully' });
  }
}
